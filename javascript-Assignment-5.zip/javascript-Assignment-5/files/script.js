
roundNum = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        return alert('pleas enter your value')
    }
    let round = Math.round(inputField)
    document.getElementById('Result').innerHTML = round
}

floorNum = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        return alert('pleas enter your value')
    }
    let floor = Math.floor(inputField)
    document.getElementById('Result').innerHTML = floor
}
ceilNum = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        return alert('pleas enter your value')
    }
    let ceil = Math.ceil(inputField)
    document.getElementById('Result').innerHTML = ceil
}

rendom = () => {
    let rendom = Math.random()
    document.getElementById('Result').innerHTML = '<h3 style="color:green;">' + rendom + '</h3>Genrate A Rendom Number '
}

throwDice = () => {
    let rend = Math.random()
    let run = (rend * 6) + 1
    run = Math.floor(run)
    let html = '<h1 style="color:green;">' + run + '</h1>Throw A Dice Number '
    document.getElementById('Result').innerHTML = html

}

strongPassword = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        alert('please enter your password')
    }
    let rendomstring = ''
    let lowerCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    let upperCase = "bcdefghijklmnopqrstuwxyz"
    let numbr = "0123456789"
    let symbles = "/!@#$%^&*~`,"
    let possiblestring = lowerCase + upperCase + numbr + symbles

    // let limit = inputField

    for (let index = 0; index < inputField; index++) {
        let rendomNumber = Math.random()
        rendomstring += possiblestring.charAt(Math.floor(rendomNumber * possiblestring.length))
    }

    document.getElementById('Result').innerHTML = rendomstring
}

convertingString = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        return alert("please enter your number")
    }
    console.log(typeof inputField);
    let num1 = parseInt(inputField)
    // let num1 = parseFloat(inputField)
    // let num1 = Number(inputField)
    // num1 = num1.toFixed(2)
    console.log(num1);
    console.log(typeof num1);
}

caluclateGST = () => {
    let inputField = document.getElementById('inputField').value
    if (!inputField) {
        return alert('please enter your amount')
    }
    inputField = Number(inputField)
    let text = +prompt('please enter your amount')
    let cost = inputField * (text / 100)
    cost = Math.round(cost)
    let total = inputField + cost
    console.log(total);
    let html = "<p> Your bill = <span style ='font-weight:bold'> " + inputField + "</span> </p>" + "<p>text 17% =<span style ='font-weight:bold;color:red;'>" + cost + '</span> </p>' + "<p>Total Amount =<span style ='font-weight:bold;color:green;'>" + total + '</span> </p>'
    document.getElementById('Result').innerHTML = html

}




















// roundNum = () => {
//     let inputField = document.getElementById('inputField').value
//     if (!inputField) {
//         return  alert('please enter your roundNumber')
//     }
//     let round = Math.round(inputField)
//      document.getElementById('Result').innerHTML = round

// }

// ceilNum = () => {
//     let inputField = document.getElementById('inputField').value
//     if (!inputField) {
//         return  alert('please enter your ceilNumber')
//     }
//     let ceil = Math.ceil(inputField)
//      document.getElementById('Result').innerHTML = ceil

// }

// floorNum = () => {
//     let inputField = document.getElementById('inputField').value
//     if (!inputField) {
//         return  alert('please enter your floorNumber')
//     }
//     let floor = Math.floor(inputField)
//      document.getElementById('Result').innerHTML = floor

// }

// rendom = () => {
//     let random = Math.random()
//      document.getElementById('Result').innerHTML = random

// }

// throwDice = () => {
//     let random = Math.random()
//     let dice =Math.floor((random*6)+1)
//      document.getElementById('Result').innerHTML = dice
     
//     }

// strongPassword = () => {
//     let ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
//     let abc = 'abcdefghijklmnopqrstuvwxyz'
//     let symbol = '!@#$%^&*;,./'
//     let possiblestring = ABC + abc + symbol
//     let string = ""

//     for (let index = 0; index < 16; index++) {
//       string += possiblestring.charAt(Math.floor(Math.random()*possiblestring.length))
//       document.getElementById('Result').innerHTML = string        
//     }
           
// } 

// let random = Math.random().toString(36).slice(2)
// console.log(random);



